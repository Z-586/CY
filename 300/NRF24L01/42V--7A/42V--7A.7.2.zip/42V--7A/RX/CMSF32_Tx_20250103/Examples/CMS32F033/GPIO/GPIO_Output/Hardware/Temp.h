#ifndef Temp_H__
#define Temp_H__

#include "cms32f033.h"
#include "stdio.h"
#include "delay.h"

//uint32_t Verge(uint16_t Adc);
void TX_TEMPER_1(void);
float V_Float(uint32_t AD_V);


#endif
