#ifndef CRC_H__
#define CRC_H__
#include "cms32f033.h"
#include "stdio.h"

uint16_t usCRC16( uint8_t * pucFrame, uint16_t usLen );

#endif

